## ----setup, include = FALSE----------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ---- fig.show='hold'----------------------------------------------------
load("comparisons.Rda")
plot(comparisons$jaccard,  type = "l", frame.plot = F, lwd = 1.5, main = "Jaccard index", xlab = "N", ylab = "Jaccard index")
plot(comparisons$sorensen,  type = "l", frame.plot = F, lwd = 1.5, main = "Sorensen index", xlab = "N", ylab = "Sorensen index")

## ---- fig.show='hold'----------------------------------------------------
load("comparisons.Rda")
plot(comparisons$morisita,  type = "l", frame.plot = F, lwd = 2, main = "Morisita index", xlab = "N", ylab = "Morisita index")
plot(comparisons$sqeudist,  type = "l", frame.plot = F, lwd = 2, main = "Squared Euclidian distance", xlab = "N", ylab = "Squared Euclidian distance")
plot(comparisons$renkonen,  type = "l", frame.plot = F, lwd = 2, main = "Renkonen index", xlab = "N", ylab = "Renkonen index")
plot(comparisons$canber,  type = "l", frame.plot = F, lwd = 2, main = "Canberra metric", xlab = "N", ylab = "Canberra metric")
plot(comparisons$log_sorensen, cex = 0.5, frame.plot = F, main = "LogSorensen index", xlab = "N", ylab = "Log Modified Sorensen Index")

## ---- fig.show='hold'----------------------------------------------------
load("comparisons.Rda")
plot(comparisons$braycurtis,  type = "l", frame.plot = F, lwd = 2, main = "Bray-Curtis index", xlab = "N", ylab = "Bray-Curtis index")
plot(comparisons$sbraycurtis,  type = "l", frame.plot = F, lwd = 2, main = "Squared Bray-Curtis index", xlab = "N", ylab = "Bray-Curtis index^2")

